<?php
$host = "localhost";
$username = "root";
$password = "";
$db = "laporan";



$connect = mysqli_connect($host,$username,$password,$db);
$mysqli = new mysqli($host, $username, $password, $db);

  
?>